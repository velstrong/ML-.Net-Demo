// 基础组件
export enum CustomBlocksType {
  MY_FIRST_BLOCK = 'MY_FIRST_BLOCK',
  PRODUCT_RECOMMENDATION = 'product_recommendation',
  ENBD_SOCIAL='enbd_social',
  IMAGE_WITH_TEXT='image_with_text'
}
